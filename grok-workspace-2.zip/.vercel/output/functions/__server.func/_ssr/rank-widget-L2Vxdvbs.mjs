import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as BadgeCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rank-widget-L2Vxdvbs.js
var import_jsx_runtime = require_jsx_runtime();
var BANDS = [
	{
		level: 1,
		min: 100,
		max: 500
	},
	{
		level: 2,
		min: 501,
		max: 750
	},
	{
		level: 3,
		min: 751,
		max: 900
	},
	{
		level: 4,
		min: 901,
		max: 1050
	},
	{
		level: 5,
		min: 1051,
		max: 1200
	},
	{
		level: 6,
		min: 1201,
		max: 1350
	},
	{
		level: 7,
		min: 1351,
		max: 1530
	},
	{
		level: 8,
		min: 1531,
		max: 1750
	},
	{
		level: 9,
		min: 1751,
		max: 2e3
	},
	{
		level: 10,
		min: 2001,
		max: Number.POSITIVE_INFINITY
	}
];
var COUNTRIES = [
	"SE",
	"DK",
	"NO",
	"FI",
	"PL",
	"DE",
	"FR",
	"NL",
	"PT",
	"ES",
	"CZ",
	"UA",
	"BR",
	"US",
	"CA",
	"GB",
	"TR",
	"KZ",
	"AU",
	"JP"
];
var LEVEL_TEXT = [
	"",
	"text-lv1",
	"text-lv2",
	"text-lv3",
	"text-lv4",
	"text-lv5",
	"text-lv6",
	"text-lv7",
	"text-lv8",
	"text-lv9",
	"text-lv10"
];
var LEVEL_BG = [
	"",
	"bg-lv1",
	"bg-lv2",
	"bg-lv3",
	"bg-lv4",
	"bg-lv5",
	"bg-lv6",
	"bg-lv7",
	"bg-lv8",
	"bg-lv9",
	"bg-lv10"
];
var DEFAULT_PROFILE = {
	nick: "nightshift",
	elo: 2146,
	followElo: true,
	level: 10,
	challenger: false,
	kd: 1.18,
	hs: 49,
	winRate: 54,
	wins: 3,
	losses: 1,
	form: [
		"W",
		"W",
		"L",
		"W",
		"W"
	],
	country: "SE",
	membership: "plus",
	verified: true,
	skin: "signal",
	plate: "ink",
	badge: "bars",
	stamp: true
};
var NICKS = [
	"nightshift",
	"lowtab",
	"dust2dad",
	"mirageonly",
	"stackdiff",
	"eco_fine",
	"awp_tax",
	"banana_peel",
	"forcebuy",
	"save_round",
	"lurking",
	"headtap",
	"veto_bot",
	"ct_anchor",
	"definitely10"
];
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function levelFromElo(elo) {
	if (elo <= BANDS[0].max) return 1;
	for (const band of BANDS) if (elo <= band.max) return band.level;
	return 10;
}
function shownLevel(profile) {
	return profile.followElo ? levelFromElo(profile.elo) : clamp(Math.round(profile.level), 1, 10);
}
function isChallenger(profile) {
	return shownLevel(profile) === 10 && profile.challenger;
}
function readElo(elo) {
	const level = levelFromElo(elo);
	const band = BANDS[level - 1];
	if (level === 10) {
		const over = Math.max(0, elo - 2001);
		return {
			level,
			pct: Math.min(1, over / 1e3),
			next: null,
			over
		};
	}
	const span = band.max - band.min;
	const into = clamp(elo - band.min, 0, span);
	return {
		level,
		pct: span === 0 ? 1 : into / span,
		next: band.max + 1,
		over: 0
	};
}
function formatElo(n) {
	return Math.round(n).toLocaleString("en-US");
}
function bandLabel(level) {
	const band = BANDS[clamp(level, 1, 10) - 1];
	if (band.level === 10) return "2,001+";
	return `${formatElo(band.min)}–${formatElo(band.max)}`;
}
function todayDelta(profile) {
	return profile.wins * 25 - profile.losses * 23;
}
function progressCopy(profile) {
	const shown = shownLevel(profile);
	const read = readElo(profile.elo);
	if (!profile.followElo) {
		if (isChallenger(profile)) return "Challenger";
		if (shown === 10) return "Level 10";
		return `Level ${shown}`;
	}
	if (read.next == null) return `${formatElo(read.over)} past 2,001`;
	return `${formatElo(Math.max(0, read.next - profile.elo))} to level ${read.level + 1}`;
}
function barState(profile) {
	const shown = shownLevel(profile);
	if (!profile.followElo) return {
		pct: shown === 10 ? 1 : .72,
		colorLevel: shown
	};
	const read = readElo(profile.elo);
	return {
		pct: read.pct,
		colorLevel: read.level
	};
}
function asForm(raw, fallback) {
	if (!raw) return fallback;
	const marks = raw.toUpperCase().split("").filter((c) => c === "W" || c === "L");
	if (marks.length === 0) return fallback;
	while (marks.length < 5) marks.push("L");
	return marks.slice(0, 5);
}
function member(v) {
	if (v === "plus" || v === "elite" || v === "none") return v;
	return "none";
}
function sanitize(input) {
	const elo = clamp(Math.round(Number.isFinite(input.elo) ? input.elo : DEFAULT_PROFILE.elo), 1, 9999);
	const followElo = input.followElo !== false;
	const level = clamp(Math.round(input.level ?? levelFromElo(elo)), 1, 10);
	const form = Array.isArray(input.form) && input.form.length === 5 ? input.form.map((m) => m === "L" ? "L" : "W") : DEFAULT_PROFILE.form;
	const skin = input.skin === "badge" || input.skin === "slab" || input.skin === "lower" || input.skin === "card" || input.skin === "signal" ? input.skin : "signal";
	const plate = input.plate === "clear" || input.plate === "glass" || input.plate === "ink" ? input.plate : "ink";
	const badge = input.badge === "plate" || input.badge === "bars" ? input.badge : "bars";
	const membership = member(input.membership);
	const country = COUNTRIES.includes(input.country) ? input.country : DEFAULT_PROFILE.country;
	const shown = followElo ? levelFromElo(elo) : level;
	return {
		nick: (input.nick ?? DEFAULT_PROFILE.nick).slice(0, 16),
		elo,
		followElo,
		level,
		challenger: shown === 10 && Boolean(input.challenger),
		kd: Math.round(clamp(input.kd ?? DEFAULT_PROFILE.kd, .1, 4) * 100) / 100,
		hs: clamp(Math.round(input.hs ?? DEFAULT_PROFILE.hs), 0, 100),
		winRate: clamp(Math.round(input.winRate ?? DEFAULT_PROFILE.winRate), 0, 100),
		wins: clamp(Math.round(input.wins ?? 0), 0, 20),
		losses: clamp(Math.round(input.losses ?? 0), 0, 20),
		form,
		country,
		membership,
		verified: Boolean(input.verified),
		skin,
		plate,
		badge,
		stamp: input.stamp !== false
	};
}
function num(v) {
	if (v == null || v.trim() === "") return void 0;
	const n = Number(v);
	return Number.isFinite(n) ? n : void 0;
}
function profileFromSearch(search) {
	if (!Object.values(search).some((value) => value != null && value !== "")) return sanitize(DEFAULT_PROFILE);
	const elo = num(search.e);
	const cl = num(search.cl);
	const custom = cl != null && cl >= 1 && cl <= 10;
	return sanitize({
		nick: search.n ?? DEFAULT_PROFILE.nick,
		elo: elo ?? DEFAULT_PROFILE.elo,
		followElo: !custom,
		level: custom ? cl : levelFromElo(elo ?? DEFAULT_PROFILE.elo),
		challenger: search.ch === "1",
		kd: num(search.k),
		hs: num(search.h),
		winRate: num(search.wr),
		wins: num(search.wi),
		losses: num(search.lo),
		form: asForm(search.f, DEFAULT_PROFILE.form),
		country: search.cc,
		membership: member(search.m),
		verified: search.v === "1",
		skin: search.s,
		plate: search.p,
		badge: search.b,
		stamp: search.mk !== "0"
	});
}
function toQuery(profile) {
	const q = new URLSearchParams();
	q.set("n", profile.nick);
	q.set("e", String(profile.elo));
	q.set("cl", profile.followElo ? "0" : String(shownLevel(profile)));
	q.set("ch", profile.challenger ? "1" : "0");
	q.set("k", String(profile.kd));
	q.set("h", String(profile.hs));
	q.set("wr", String(profile.winRate));
	q.set("wi", String(profile.wins));
	q.set("lo", String(profile.losses));
	q.set("f", profile.form.join(""));
	q.set("cc", profile.country);
	q.set("m", profile.membership);
	q.set("v", profile.verified ? "1" : "0");
	q.set("s", profile.skin);
	q.set("p", profile.plate);
	q.set("mk", profile.stamp ? "1" : "0");
	q.set("b", profile.badge);
	return q.toString();
}
var PRESETS = [
	{
		id: "washed",
		label: "Washed",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "dust2dad",
			elo: 612,
			followElo: true,
			challenger: false,
			kd: .84,
			hs: 36,
			winRate: 41,
			wins: 0,
			losses: 3,
			form: [
				"L",
				"L",
				"W",
				"L",
				"L"
			],
			country: "US",
			membership: "none",
			verified: false
		})
	},
	{
		id: "lobby",
		label: "Lobby",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "mirageonly",
			elo: 1124,
			followElo: true,
			kd: 1.02,
			hs: 46,
			winRate: 50,
			wins: 1,
			losses: 1,
			form: [
				"W",
				"L",
				"W",
				"L",
				"W"
			],
			country: "PL",
			membership: "none",
			verified: false
		})
	},
	{
		id: "grinder",
		label: "Grinder",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "stackdiff",
			elo: 1688,
			followElo: true,
			kd: 1.14,
			hs: 51,
			winRate: 55,
			wins: 2,
			losses: 1,
			form: [
				"W",
				"W",
				"W",
				"L",
				"W"
			],
			country: "DK",
			membership: "plus",
			verified: true
		})
	},
	{
		id: "ten",
		label: "Level 10",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "nightshift",
			elo: 2388,
			followElo: true,
			challenger: false,
			kd: 1.27,
			hs: 54,
			winRate: 58,
			wins: 4,
			losses: 1,
			form: [
				"W",
				"W",
				"L",
				"W",
				"W"
			],
			country: "SE",
			membership: "elite",
			verified: true
		})
	},
	{
		id: "challenger",
		label: "Challenger",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "lowtab",
			elo: 3410,
			followElo: true,
			challenger: true,
			kd: 1.42,
			hs: 58,
			winRate: 63,
			wins: 5,
			losses: 0,
			form: [
				"W",
				"W",
				"W",
				"W",
				"W"
			],
			country: "FR",
			membership: "elite",
			verified: true
		})
	},
	{
		id: "liar",
		label: "Obvious lie",
		profile: sanitize({
			...DEFAULT_PROFILE,
			nick: "definitely10",
			elo: 420,
			followElo: false,
			level: 10,
			challenger: true,
			kd: 3.2,
			hs: 80,
			winRate: 92,
			wins: 9,
			losses: 0,
			form: [
				"W",
				"W",
				"W",
				"W",
				"W"
			],
			country: "BR",
			membership: "elite",
			verified: true,
			stamp: true
		})
	}
];
function randomProfile(current) {
	const nick = NICKS[Math.floor(Math.random() * NICKS.length)];
	const elo = Math.random() > .85 ? 2e3 + Math.floor(Math.random() * 1800) : 200 + Math.floor(Math.random() * 1900);
	const form = Array.from({ length: 5 }, () => Math.random() > .45 ? "W" : "L");
	const country = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
	return sanitize({
		...current,
		nick,
		elo,
		followElo: true,
		challenger: elo > 2800 && Math.random() > .4,
		kd: Math.round((.7 + Math.random() * 1.1) * 100) / 100,
		hs: 30 + Math.floor(Math.random() * 35),
		winRate: 38 + Math.floor(Math.random() * 30),
		wins: Math.floor(Math.random() * 6),
		losses: Math.floor(Math.random() * 4),
		form,
		country,
		verified: Math.random() > .4,
		membership: elo > 1800 ? "elite" : elo > 1100 ? "plus" : "none"
	});
}
function keepLook(current, next) {
	return sanitize({
		...next,
		skin: current.skin,
		plate: current.plate,
		badge: current.badge,
		stamp: current.stamp
	});
}
function LevelBadge({ profile, className = "" }) {
	const level = shownLevel(profile);
	const challenger = isChallenger(profile);
	const hot = level >= 9 || challenger;
	const label = challenger ? `Challenger, level ${level}` : `Level ${level}`;
	if (profile.badge === "plate") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "img",
		"aria-label": label,
		className: `grid place-items-center rounded-xl font-display leading-none text-ink ${challenger ? "bg-loss ring-2 ring-fg" : LEVEL_BG[level]} ${hot ? "badge-hot" : ""} ${className}`,
		children: level
	});
	const lit = challenger ? 10 : level;
	const color = challenger ? "text-loss" : LEVEL_TEXT[level];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		role: "img",
		"aria-label": label,
		className: `${color} ${hot ? "badge-hot" : ""} ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "1",
				y: "1",
				width: "62",
				height: "62",
				rx: "12",
				fill: "var(--color-surface-2)",
				stroke: "var(--color-border)"
			}),
			challenger ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3.5",
				y: "3.5",
				width: "57",
				height: "57",
				rx: "10",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}) : null,
			Array.from({ length: 10 }, (_, i) => {
				const on = i >= 10 - lit;
				const fromTop = i - (10 - lit);
				const y = 7 + i * 5.15;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "12",
					y,
					width: "40",
					height: "3.4",
					rx: "1.2",
					fill: on ? "currentColor" : "var(--color-border)",
					opacity: on ? 1 - fromTop * .055 : 1
				}, i);
			})
		]
	});
}
function shell(plate, extra) {
	const base = "relative text-fg";
	if (plate === "ink") return `${base} overflow-hidden rounded-xl bg-surface ring-1 ring-border ${extra}`;
	if (plate === "glass") return `${base} overflow-hidden rounded-xl bg-canvas/80 ring-1 ring-border ${extra}`;
	return `${base} plate-clear ${extra}`;
}
function Meter({ pct, level, flush = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: flush ? "h-1 w-full bg-border" : "h-1.5 w-full overflow-hidden rounded-full bg-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `h-full ${LEVEL_BG[level]} ${flush ? "" : "rounded-full"}`,
			style: { width: `${Math.round(Math.min(1, Math.max(0, pct)) * 100)}%` }
		})
	});
}
function FormRow({ form }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1",
		"aria-label": "Recent results",
		children: form.map((mark, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `grid h-5 w-5 place-items-center rounded-sm font-display text-xs text-ink ${mark === "W" ? "bg-win" : "bg-loss"}`,
			children: mark
		}, i))
	});
}
function MemberPill({ profile }) {
	if (profile.membership === "none") return null;
	if (profile.membership === "elite") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-sm bg-primary px-1.5 py-0.5 font-display text-xs tracking-wide text-ink",
		children: "ELITE"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-sm bg-surface-2 px-1.5 py-0.5 font-display text-xs tracking-wide text-fg ring-1 ring-border",
		children: "PLUS"
	});
}
function Delta({ profile }) {
	const delta = todayDelta(profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `font-display text-sm tabular-nums ${delta > 0 ? "text-win" : delta < 0 ? "text-loss" : "text-muted"}`,
		children: [
			delta > 0 ? "+" : "",
			delta,
			" today"
		]
	});
}
function Meta({ profile }) {
	const level = shownLevel(profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tracking-wide text-fg",
				children: profile.country
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberPill, { profile }),
			profile.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
				className: "size-3.5 text-primary",
				"aria-label": "Verified"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tracking-wide text-fg",
				children: isChallenger(profile) ? "Challenger" : `Level ${level}`
			}),
			profile.stamp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tracking-widest",
				children: "FAKEIT"
			}) : null
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-lg leading-none tabular-nums text-fg",
			children: v
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-xs tracking-widest text-muted",
			children: k
		})]
	});
}
function Monogram({ profile }) {
	const letters = (profile.nick.replace(/[^a-zA-Z0-9]/g, "").slice(0, 2) || "P").toUpperCase();
	const level = shownLevel(profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `grid size-12 shrink-0 place-items-center rounded-full bg-surface-2 ring-2 ${isChallenger(profile) ? "ring-loss" : `ring-current ${LEVEL_TEXT[level]}`}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-lg text-fg",
			children: letters
		})
	});
}
function RankWidget({ profile }) {
	const nick = profile.nick.trim() || "player";
	const level = shownLevel(profile);
	const bar = barState(profile);
	const elo = formatElo(profile.elo);
	const caption = progressCopy(profile);
	if (profile.skin === "badge") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: shell(profile.plate, "flex w-fit flex-col items-center gap-3 px-8 py-6"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, {
				profile,
				className: "size-24 text-5xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-lg uppercase tracking-widest text-fg",
				children: isChallenger(profile) ? "Challenger" : `Level ${level}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-sm tracking-widest text-muted",
				children: nick
			}),
			profile.stamp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-xs tracking-widest text-muted",
				children: "FAKEIT"
			}) : null
		]
	});
	if (profile.skin === "slab") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: shell(profile.plate, "p-5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate font-display text-xl uppercase tracking-wide text-fg",
						children: nick
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { profile })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, {
					profile,
					className: "size-14 shrink-0 text-2xl"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 font-display text-5xl leading-none tabular-nums text-fg",
				children: elo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs tracking-widest text-muted",
				children: "ELO"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "K/D",
						v: profile.kd.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "HS",
						v: `${profile.hs}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "WIN",
						v: `${profile.winRate}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
					pct: bar.pct,
					level: bar.colorLevel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: caption
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delta, { profile })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: profile.form })
			})
		]
	});
	if (profile.skin === "lower") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: shell(profile.plate, ""),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, {
					profile,
					className: "size-12 shrink-0 text-xl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-px shrink-0 bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate font-display text-2xl uppercase leading-none tracking-wide text-fg",
						children: nick
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex flex-wrap items-center gap-2 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								profile.kd.toFixed(2),
								" K/D · ",
								profile.winRate,
								"% WR"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: profile.form })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shrink-0 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-4xl leading-none tabular-nums text-fg",
						children: elo
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs tracking-widest text-muted",
						children: "ELO"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
			pct: bar.pct,
			level: bar.colorLevel,
			flush: true
		})]
	});
	if (profile.skin === "card") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: shell(profile.plate, "p-4"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monogram, { profile }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-display text-xl uppercase tracking-wide text-fg",
								children: nick
							}), profile.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
								className: "size-4 shrink-0 text-primary",
								"aria-label": "Verified"
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { profile })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, {
						profile,
						className: "size-12 shrink-0 text-xl"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-4xl leading-none tabular-nums text-fg",
					children: elo
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-xs tracking-widest text-muted",
					children: "ELO"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delta, { profile })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-2 border-t border-border pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "K/D",
						v: profile.kd.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "HS",
						v: `${profile.hs}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "WIN",
						v: `${profile.winRate}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: profile.form }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: caption
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: shell(profile.plate, "p-4"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelBadge, {
				profile,
				className: "size-16 shrink-0 text-3xl"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate font-display text-2xl uppercase leading-none tracking-wide text-fg",
							children: nick
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, { profile })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-3xl leading-none tabular-nums text-fg",
							children: elo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs tracking-widest text-muted",
							children: "ELO"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						pct: bar.pct,
						level: bar.colorLevel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: caption
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: profile.form }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delta, { profile })]
						})]
					})]
				})]
			})]
		})
	});
}
var SKIN_FRAME = {
	badge: "w-fit",
	signal: "w-full max-w-md",
	slab: "w-full max-w-xs",
	lower: "w-full max-w-2xl",
	card: "w-full max-w-sm"
};
//#endregion
export { todayDelta as _, PRESETS as a, bandLabel as c, levelFromElo as d, profileFromSearch as f, toQuery as g, shownLevel as h, LEVEL_BG as i, formatElo as l, sanitize as m, COUNTRIES as n, RankWidget as o, randomProfile as p, DEFAULT_PROFILE as r, SKIN_FRAME as s, BANDS as t, keepLook as u };
