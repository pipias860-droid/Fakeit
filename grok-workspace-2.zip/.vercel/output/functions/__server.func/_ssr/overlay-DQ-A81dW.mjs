import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-DDfO1dvB.mjs";
import { f as profileFromSearch, o as RankWidget } from "./rank-widget-L2Vxdvbs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/overlay-DQ-A81dW.js
var import_jsx_runtime = require_jsx_runtime();
function OverlayPage() {
	const search = Route.useSearch();
	const profile = profileFromSearch(search);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-overlay": true,
		className: "min-h-screen bg-transparent",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankWidget, { profile })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "fixed bottom-3 left-1/2 -translate-x-1/2 text-xs text-muted underline decoration-border",
			children: "Back to studio"
		})]
	});
}
//#endregion
export { OverlayPage as component };
