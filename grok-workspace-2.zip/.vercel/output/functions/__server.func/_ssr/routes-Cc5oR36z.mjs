import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Download, n as Shuffle, r as Link2 } from "../_libs/lucide-react.mjs";
import { _ as todayDelta, a as PRESETS, c as bandLabel, d as levelFromElo, g as toQuery, h as shownLevel, i as LEVEL_BG, l as formatElo, m as sanitize, n as COUNTRIES, o as RankWidget, p as randomProfile, r as DEFAULT_PROFILE, s as SKIN_FRAME, t as BANDS, u as keepLook } from "./rank-widget-L2Vxdvbs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cc5oR36z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "fakeit-profile-v1";
var SKINS = [
	{
		id: "signal",
		label: "Signal"
	},
	{
		id: "slab",
		label: "Slab"
	},
	{
		id: "lower",
		label: "Lower third"
	},
	{
		id: "card",
		label: "Player card"
	},
	{
		id: "badge",
		label: "Badge"
	}
];
var PLATES = [
	{
		id: "ink",
		label: "Ink"
	},
	{
		id: "glass",
		label: "Glass"
	},
	{
		id: "clear",
		label: "Clear"
	}
];
var BADGES = [{
	id: "bars",
	label: "Bars"
}, {
	id: "plate",
	label: "Number"
}];
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mb-1.5 flex items-baseline justify-between gap-3 text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-fg",
				children: hint
			}) : null]
		}), children]
	});
}
var control = "h-11 w-full rounded-lg bg-canvas px-3 text-fg ring-1 ring-border outline-none focus:ring-primary";
function Studio() {
	const [profile, setProfile] = (0, import_react.useState)(DEFAULT_PROFILE);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)("");
	const [exporting, setExporting] = (0, import_react.useState)(false);
	const [box, setBox] = (0, import_react.useState)({
		w: 0,
		h: 0
	});
	const [origin, setOrigin] = (0, import_react.useState)("");
	const frameRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) setProfile(sanitize(JSON.parse(raw)));
		} catch {}
		setOrigin(window.location.origin);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
	}, [profile, ready]);
	(0, import_react.useEffect)(() => {
		const node = frameRef.current;
		if (!node) return;
		const measure = () => {
			const rect = node.getBoundingClientRect();
			setBox({
				w: Math.round(rect.width),
				h: Math.round(rect.height)
			});
		};
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(node);
		return () => observer.disconnect();
	}, [
		profile.skin,
		profile.plate,
		profile.badge
	]);
	function update(patch) {
		setProfile((prev) => sanitize({
			...prev,
			...patch
		}));
		setNotice("");
	}
	const shown = shownLevel(profile);
	const natural = levelFromElo(profile.elo);
	const delta = todayDelta(profile);
	const href = `${origin}/overlay?${toQuery(profile)}`;
	async function copyLink() {
		try {
			await navigator.clipboard.writeText(href);
			setNotice("Overlay link copied");
		} catch {
			setNotice("Select the link and copy it");
		}
	}
	async function download() {
		const node = frameRef.current;
		if (!node) return;
		setExporting(true);
		setNotice("");
		try {
			const { domToPng } = await import("../_libs/modern-screenshot.mjs").then((n) => n.t);
			const url = await domToPng(node, {
				scale: 2,
				backgroundColor: profile.plate === "clear" ? null : void 0
			});
			const slug = (profile.nick || "player").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
			const a = document.createElement("a");
			a.href = url;
			a.download = `fakeit-${slug || "player"}-lv${shown}.png`;
			a.click();
			setNotice("PNG saved");
		} catch {
			setNotice("Export failed. Use the overlay link instead.");
		} finally {
			setExporting(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-canvas text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs tracking-widest text-primary",
						children: "WIDGET STUDIO"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl uppercase leading-none text-fg",
						children: "Fakeit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-pretty text-sm text-muted",
						children: "Fake skill widgets for streams and screenshots. Dial in a nickname, Elo, and level badge, then grab a PNG or a transparent overlay link."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setProfile((prev) => randomProfile(prev)),
					className: "inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-4 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-4" }), "Random"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "order-1 flex flex-col gap-4 lg:order-2 lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-sm tracking-widest text-muted",
								children: "PREVIEW"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [box.w > 0 ? `OBS size ${box.w} × ${box.h}` : "Measuring", profile.plate === "clear" ? " · transparent" : ""]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: download,
									disabled: exporting,
									className: "inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-medium text-ink transition-colors hover:bg-primary/90 disabled:opacity-60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), exporting ? "Exporting" : "Download PNG"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: copyLink,
									className: "inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-4 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), "Copy overlay"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "stage-checker flex min-h-56 items-center justify-center rounded-xl p-6 ring-1 ring-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								ref: frameRef,
								className: SKIN_FRAME[profile.skin],
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankWidget, { profile })
							})
						}),
						!profile.followElo && natural !== shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Elo ",
								formatElo(profile.elo),
								" normally wears level ",
								natural,
								" (",
								bandLabel(natural),
								"). The badge is forced to level ",
								shown,
								"."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Level ",
								natural,
								" is ",
								bandLabel(natural),
								".",
								shown === 10 ? " Level 10 starts at 2,001." : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1.5 block text-xs text-muted",
								children: "Overlay link for OBS browser source"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								readOnly: true,
								value: href,
								className: `${control} text-sm`,
								onFocus: (e) => e.currentTarget.select()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["Add a browser source, paste the link, set the size above, and enable a transparent background. The back link sits at the bottom of that page so a tight crop leaves it out.", notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-fg",
								children: notice
							}) : null]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "order-2 flex flex-col gap-4 lg:order-1 lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setProfile((prev) => keepLook(prev, preset.profile)),
								className: "h-11 rounded-lg bg-surface px-3 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2",
								children: preset.label
							}, preset.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-sm tracking-widest text-muted",
									children: "IDENTITY"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nickname",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: control,
										maxLength: 16,
										value: profile.nick,
										onChange: (e) => update({ nick: e.target.value }),
										spellCheck: false
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Region",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											className: control,
											value: profile.country,
											onChange: (e) => update({ country: e.target.value }),
											children: COUNTRIES.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: code,
												children: code
											}, code))
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Tag",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: control,
											value: profile.membership,
											onChange: (e) => update({ membership: e.target.value }),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "none",
													children: "None"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "plus",
													children: "Plus"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "elite",
													children: "Elite"
												})
											]
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: profile.verified,
										label: "Verified",
										onClick: () => update({ verified: !profile.verified })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: profile.stamp,
										label: "FAKEIT stamp",
										onClick: () => update({ stamp: !profile.stamp })
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-sm tracking-widest text-muted",
									children: "RANK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
									label: "Elo",
									hint: formatElo(profile.elo),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 100,
										max: 4e3,
										value: Math.min(4e3, profile.elo),
										onChange: (e) => update({ elo: Number(e.target.value) })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 1,
										max: 9999,
										value: profile.elo,
										onChange: (e) => update({ elo: Number(e.target.value) }),
										className: `${control} mt-2 tabular-nums`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
									on: profile.followElo,
									label: "Badge follows Elo",
									onClick: () => update({
										followElo: !profile.followElo,
										level: natural
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 gap-2",
									children: BANDS.map((band) => {
										const active = shown === band.level;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => update({
												followElo: false,
												level: band.level,
												challenger: band.level === 10 ? profile.challenger : false
											}),
											className: `h-11 rounded-lg font-display text-lg text-ink transition-opacity ${LEVEL_BG[band.level]} ${active ? "ring-2 ring-fg" : "opacity-70 hover:opacity-100"}`,
											"aria-pressed": active,
											children: band.level
										}, band.level);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										if (profile.challenger && shown === 10) {
											update({ challenger: false });
											return;
										}
										update({
											challenger: true,
											level: 10,
											followElo: natural === 10 ? profile.followElo : false
										});
									},
									className: `h-11 rounded-lg font-display tracking-widest ring-1 transition-colors ${profile.challenger && shown === 10 ? "bg-loss text-ink ring-loss" : "bg-canvas text-fg ring-border hover:bg-surface-2"}`,
									"aria-pressed": profile.challenger && shown === 10,
									children: "CHALLENGER"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										"Staged today: ",
										delta > 0 ? "+" : "",
										delta,
										" from ",
										profile.wins,
										"W ",
										profile.losses,
										"L. Public bands, not a live account."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-sm tracking-widest text-muted",
									children: "STATS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "K/D",
									hint: profile.kd.toFixed(2),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: .4,
										max: 3,
										step: .01,
										value: profile.kd,
										onChange: (e) => update({ kd: Number(e.target.value) })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "HS %",
										hint: `${profile.hs}%`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 10,
											max: 80,
											value: profile.hs,
											onChange: (e) => update({ hs: Number(e.target.value) })
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Win rate",
										hint: `${profile.winRate}%`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 20,
											max: 80,
											value: profile.winRate,
											onChange: (e) => update({ winRate: Number(e.target.value) })
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "Wins today",
										value: profile.wins,
										onChange: (wins) => update({ wins })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "Losses today",
										value: profile.losses,
										onChange: (losses) => update({ losses })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1.5 text-xs text-muted",
									children: "Last five"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 gap-2",
									children: profile.form.map((mark, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											const form = profile.form.slice();
											form[i] = mark === "W" ? "L" : "W";
											update({ form });
										},
										className: `h-11 rounded-lg font-display text-lg text-ink ${mark === "W" ? "bg-win" : "bg-loss"}`,
										"aria-label": `Match ${i + 1}, ${mark === "W" ? "win" : "loss"}`,
										children: mark
									}, i))
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-sm tracking-widest text-muted",
									children: "LOOK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									label: "Layout",
									value: profile.skin,
									options: SKINS,
									onChange: (skin) => update({ skin })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									label: "Plate",
									value: profile.plate,
									options: PLATES,
									onChange: (plate) => update({ plate })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
									label: "Badge",
									value: profile.badge,
									options: BADGES,
									onChange: (badge) => update({ badge })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-pretty text-muted",
							children: "Fan-made prop. Level bands match the public 1–10 Elo table. Not affiliated with FACEIT or any matchmaking platform. Nothing here is a real rating."
						})
					]
				})]
			})]
		})
	});
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick,
		className: "flex h-11 items-center justify-between gap-3 rounded-lg bg-canvas px-3 text-sm text-fg ring-1 ring-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `h-5 w-9 rounded-full p-0.5 transition-colors ${on ? "bg-primary" : "bg-border"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block size-4 rounded-full bg-fg transition-transform ${on ? "translate-x-4" : ""}` })
		})]
	});
}
function Stepper({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1.5 text-xs text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-11 overflow-hidden rounded-lg ring-1 ring-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-11 bg-canvas text-lg text-fg hover:bg-surface-2",
				onClick: () => onChange(value - 1),
				"aria-label": `Decrease ${label}`,
				children: "−"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid flex-1 place-items-center bg-canvas font-display text-lg tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-11 bg-canvas text-lg text-fg hover:bg-surface-2",
				onClick: () => onChange(value + 1),
				"aria-label": `Increase ${label}`,
				children: "+"
			})
		]
	})] });
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1.5 text-xs text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((option) => {
			const active = option.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(option.id),
				"aria-pressed": active,
				className: `h-11 rounded-lg px-3 text-sm transition-colors ${active ? "bg-primary text-ink" : "bg-canvas text-fg ring-1 ring-border hover:bg-surface-2"}`,
				children: option.label
			}, option.id);
		})
	})] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
