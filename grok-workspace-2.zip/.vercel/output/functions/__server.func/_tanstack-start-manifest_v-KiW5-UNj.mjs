//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-KiW5-UNj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/overlay"],
		preloads: ["/assets/index-DyP8EywZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DyP8EywZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DjmSuass.js", "/assets/rank-widget-3fjWGFZM.js"]
	},
	"/overlay": {
		filePath: "/workspace/src/routes/overlay.tsx",
		children: void 0,
		preloads: ["/assets/overlay-B-ee-vEM.js", "/assets/rank-widget-3fjWGFZM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
