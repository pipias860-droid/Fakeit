import { BadgeCheck } from "lucide-react";
import { LevelBadge } from "@/components/level-badge";
import {
  barState,
  formatElo,
  isChallenger,
  LEVEL_BG,
  LEVEL_TEXT,
  progressCopy,
  shownLevel,
  todayDelta,
  type FormMark,
  type Plate,
  type Profile,
} from "@/lib/profile";

function shell(plate: Plate, extra: string) {
  const base = "relative text-fg";
  if (plate === "ink") return `${base} overflow-hidden rounded-xl bg-surface ring-1 ring-border ${extra}`;
  if (plate === "glass") return `${base} overflow-hidden rounded-xl bg-canvas/80 ring-1 ring-border ${extra}`;
  return `${base} plate-clear ${extra}`;
}

function Meter({ pct, level, flush = false }: { pct: number; level: number; flush?: boolean }) {
  return (
    <div className={flush ? "h-1 w-full bg-border" : "h-1.5 w-full overflow-hidden rounded-full bg-border"}>
      <div
        className={`h-full ${LEVEL_BG[level]} ${flush ? "" : "rounded-full"}`}
        style={{ width: `${Math.round(Math.min(1, Math.max(0, pct)) * 100)}%` }}
      />
    </div>
  );
}

function FormRow({ form }: { form: FormMark[] }) {
  return (
    <div className="flex gap-1" aria-label="Recent results">
      {form.map((mark, i) => (
        <span
          key={i}
          className={`grid h-5 w-5 place-items-center rounded-sm font-display text-xs text-ink ${
            mark === "W" ? "bg-win" : "bg-loss"
          }`}
        >
          {mark}
        </span>
      ))}
    </div>
  );
}

function MemberPill({ profile }: { profile: Profile }) {
  if (profile.membership === "none") return null;
  if (profile.membership === "elite") {
    return <span className="rounded-sm bg-primary px-1.5 py-0.5 font-display text-xs tracking-wide text-ink">ELITE</span>;
  }
  return (
    <span className="rounded-sm bg-surface-2 px-1.5 py-0.5 font-display text-xs tracking-wide text-fg ring-1 ring-border">
      PLUS
    </span>
  );
}

function Delta({ profile }: { profile: Profile }) {
  const delta = todayDelta(profile);
  const sign = delta > 0 ? "+" : "";
  return (
    <span className={`font-display text-sm tabular-nums ${delta > 0 ? "text-win" : delta < 0 ? "text-loss" : "text-muted"}`}>
      {sign}
      {delta} today
    </span>
  );
}

function Meta({ profile }: { profile: Profile }) {
  const level = shownLevel(profile);
  return (
    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted">
      <span className="font-display tracking-wide text-fg">{profile.country}</span>
      <MemberPill profile={profile} />
      {profile.verified ? <BadgeCheck className="size-3.5 text-primary" aria-label="Verified" /> : null}
      <span className="font-display tracking-wide text-fg">
        {isChallenger(profile) ? "Challenger" : `Level ${level}`}
      </span>
      {profile.stamp ? <span className="font-display tracking-widest">FAKEIT</span> : null}
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="text-center">
      <div className="font-display text-lg leading-none tabular-nums text-fg">{v}</div>
      <div className="mt-1 text-xs tracking-widest text-muted">{k}</div>
    </div>
  );
}

function Monogram({ profile }: { profile: Profile }) {
  const letters = (profile.nick.replace(/[^a-zA-Z0-9]/g, "").slice(0, 2) || "P").toUpperCase();
  const level = shownLevel(profile);
  return (
    <div
      className={`grid size-12 shrink-0 place-items-center rounded-full bg-surface-2 ring-2 ${
        isChallenger(profile) ? "ring-loss" : `ring-current ${LEVEL_TEXT[level]}`
      }`}
    >
      <span className="font-display text-lg text-fg">{letters}</span>
    </div>
  );
}

export function RankWidget({ profile }: { profile: Profile }) {
  const nick = profile.nick.trim() || "player";
  const level = shownLevel(profile);
  const bar = barState(profile);
  const elo = formatElo(profile.elo);
  const caption = progressCopy(profile);

  if (profile.skin === "badge") {
    return (
      <div className={shell(profile.plate, "flex w-fit flex-col items-center gap-3 px-8 py-6")}>
        <LevelBadge profile={profile} className="size-24 text-5xl" />
        <div className="font-display text-lg uppercase tracking-widest text-fg">
          {isChallenger(profile) ? "Challenger" : `Level ${level}`}
        </div>
        <div className="font-display text-sm tracking-widest text-muted">{nick}</div>
        {profile.stamp ? <div className="font-display text-xs tracking-widest text-muted">FAKEIT</div> : null}
      </div>
    );
  }

  if (profile.skin === "slab") {
    return (
      <div className={shell(profile.plate, "p-5")}>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="truncate font-display text-xl uppercase tracking-wide text-fg">{nick}</div>
            <Meta profile={profile} />
          </div>
          <LevelBadge profile={profile} className="size-14 shrink-0 text-2xl" />
        </div>
        <div className="mt-4 font-display text-5xl leading-none tabular-nums text-fg">{elo}</div>
        <div className="mt-1 text-xs tracking-widest text-muted">ELO</div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          <Stat k="K/D" v={profile.kd.toFixed(2)} />
          <Stat k="HS" v={`${profile.hs}%`} />
          <Stat k="WIN" v={`${profile.winRate}%`} />
        </div>
        <div className="mt-4">
          <Meter pct={bar.pct} level={bar.colorLevel} />
          <div className="mt-2 flex items-center justify-between gap-2">
            <span className="text-xs text-muted">{caption}</span>
            <Delta profile={profile} />
          </div>
        </div>
        <div className="mt-3">
          <FormRow form={profile.form} />
        </div>
      </div>
    );
  }

  if (profile.skin === "lower") {
    return (
      <div className={shell(profile.plate, "")}>
        <div className="flex items-center gap-3 px-4 py-3">
          <LevelBadge profile={profile} className="size-12 shrink-0 text-xl" />
          <div className="h-8 w-px shrink-0 bg-border" />
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-2xl uppercase leading-none tracking-wide text-fg">{nick}</div>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted">
              <span className="tabular-nums">
                {profile.kd.toFixed(2)} K/D · {profile.winRate}% WR
              </span>
              <FormRow form={profile.form} />
            </div>
          </div>
          <div className="shrink-0 text-right">
            <div className="font-display text-4xl leading-none tabular-nums text-fg">{elo}</div>
            <div className="text-xs tracking-widest text-muted">ELO</div>
          </div>
        </div>
        <Meter pct={bar.pct} level={bar.colorLevel} flush />
      </div>
    );
  }

  if (profile.skin === "card") {
    return (
      <div className={shell(profile.plate, "p-4")}>
        <div className="flex items-center gap-3">
          <Monogram profile={profile} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="truncate font-display text-xl uppercase tracking-wide text-fg">{nick}</span>
              {profile.verified ? <BadgeCheck className="size-4 shrink-0 text-primary" aria-label="Verified" /> : null}
            </div>
            <Meta profile={profile} />
          </div>
          <LevelBadge profile={profile} className="size-12 shrink-0 text-xl" />
        </div>
        <div className="mt-4 flex items-end justify-between gap-3">
          <div>
            <div className="font-display text-4xl leading-none tabular-nums text-fg">{elo}</div>
            <div className="mt-1 text-xs tracking-widest text-muted">ELO</div>
          </div>
          <Delta profile={profile} />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 border-t border-border pt-3">
          <Stat k="K/D" v={profile.kd.toFixed(2)} />
          <Stat k="HS" v={`${profile.hs}%`} />
          <Stat k="WIN" v={`${profile.winRate}%`} />
        </div>
        <div className="mt-3 flex items-center justify-between gap-2">
          <FormRow form={profile.form} />
          <span className="text-xs text-muted">{caption}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={shell(profile.plate, "p-4")}>
      <div className="flex items-center gap-3">
        <LevelBadge profile={profile} className="size-16 shrink-0 text-3xl" />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="truncate font-display text-2xl uppercase leading-none tracking-wide text-fg">{nick}</div>
              <Meta profile={profile} />
            </div>
            <div className="shrink-0 text-right">
              <div className="font-display text-3xl leading-none tabular-nums text-fg">{elo}</div>
              <div className="text-xs tracking-widest text-muted">ELO</div>
            </div>
          </div>
          <div className="mt-3">
            <Meter pct={bar.pct} level={bar.colorLevel} />
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs text-muted">{caption}</span>
              <div className="flex items-center gap-2">
                <FormRow form={profile.form} />
                <Delta profile={profile} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export const SKIN_FRAME: Record<Profile["skin"], string> = {
  badge: "w-fit",
  signal: "w-full max-w-md",
  slab: "w-full max-w-xs",
  lower: "w-full max-w-2xl",
  card: "w-full max-w-sm",
};
