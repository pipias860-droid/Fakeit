import { useEffect, useRef, useState, type ReactNode } from "react";
import { Download, Link2, Shuffle } from "lucide-react";
import { RankWidget, SKIN_FRAME } from "@/components/rank-widget";
import {
  BANDS,
  bandLabel,
  COUNTRIES,
  DEFAULT_PROFILE,
  formatElo,
  keepLook,
  LEVEL_BG,
  levelFromElo,
  PRESETS,
  randomProfile,
  sanitize,
  shownLevel,
  toQuery,
  todayDelta,
  type BadgeStyle,
  type Plate,
  type Profile,
  type Skin,
} from "@/lib/profile";

const STORAGE_KEY = "fakeit-profile-v1";

const SKINS: { id: Skin; label: string }[] = [
  { id: "signal", label: "Signal" },
  { id: "slab", label: "Slab" },
  { id: "lower", label: "Lower third" },
  { id: "card", label: "Player card" },
  { id: "badge", label: "Badge" },
];

const PLATES: { id: Plate; label: string }[] = [
  { id: "ink", label: "Ink" },
  { id: "glass", label: "Glass" },
  { id: "clear", label: "Clear" },
];

const BADGES: { id: BadgeStyle; label: string }[] = [
  { id: "bars", label: "Bars" },
  { id: "plate", label: "Number" },
];

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between gap-3 text-xs text-muted">
        <span>{label}</span>
        {hint ? <span className="tabular-nums text-fg">{hint}</span> : null}
      </span>
      {children}
    </label>
  );
}

const control =
  "h-11 w-full rounded-lg bg-canvas px-3 text-fg ring-1 ring-border outline-none focus:ring-primary";

export function Studio() {
  const [profile, setProfile] = useState<Profile>(DEFAULT_PROFILE);
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState("");
  const [exporting, setExporting] = useState(false);
  const [box, setBox] = useState({ w: 0, h: 0 });
  const [origin, setOrigin] = useState("");
  const frameRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setProfile(sanitize(JSON.parse(raw) as Partial<Profile>));
    } catch {
      /* keep default */
    }
    setOrigin(window.location.origin);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  }, [profile, ready]);

  useEffect(() => {
    const node = frameRef.current;
    if (!node) return;
    const measure = () => {
      const rect = node.getBoundingClientRect();
      setBox({ w: Math.round(rect.width), h: Math.round(rect.height) });
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    return () => observer.disconnect();
  }, [profile.skin, profile.plate, profile.badge]);

  function update(patch: Partial<Profile>) {
    setProfile((prev) => sanitize({ ...prev, ...patch }));
    setNotice("");
  }

  const shown = shownLevel(profile);
  const natural = levelFromElo(profile.elo);
  const delta = todayDelta(profile);
  const query = toQuery(profile);
  const href = `${origin}/overlay?${query}`;

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(href);
      setNotice("Overlay link copied");
    } catch {
      setNotice("Select the link and copy it");
    }
  }

  async function download() {
    const node = frameRef.current;
    if (!node) return;
    setExporting(true);
    setNotice("");
    try {
      const { domToPng } = await import("modern-screenshot");
      const url = await domToPng(node, {
        scale: 2,
        backgroundColor: profile.plate === "clear" ? null : undefined,
      });
      const slug = (profile.nick || "player").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const a = document.createElement("a");
      a.href = url;
      a.download = `fakeit-${slug || "player"}-lv${shown}.png`;
      a.click();
      setNotice("PNG saved");
    } catch {
      setNotice("Export failed. Use the overlay link instead.");
    } finally {
      setExporting(false);
    }
  }

  return (
    <main className="min-h-screen bg-canvas text-fg">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-6">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-display text-xs tracking-widest text-primary">WIDGET STUDIO</p>
            <h1 className="font-display text-5xl uppercase leading-none text-fg">Fakeit</h1>
            <p className="mt-2 max-w-xl text-pretty text-sm text-muted">
              Fake skill widgets for streams and screenshots. Dial in a nickname, Elo, and level badge, then
              grab a PNG or a transparent overlay link.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setProfile((prev) => randomProfile(prev))}
            className="inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-4 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2"
          >
            <Shuffle className="size-4" />
            Random
          </button>
        </header>

        <div className="grid items-start gap-6 lg:grid-cols-12">
          <section className="order-1 flex flex-col gap-4 lg:order-2 lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-sm tracking-widest text-muted">PREVIEW</h2>
                <p className="text-sm text-muted">
                  {box.w > 0 ? `OBS size ${box.w} × ${box.h}` : "Measuring"}
                  {profile.plate === "clear" ? " · transparent" : ""}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={download}
                  disabled={exporting}
                  className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-medium text-ink transition-colors hover:bg-primary/90 disabled:opacity-60"
                >
                  <Download className="size-4" />
                  {exporting ? "Exporting" : "Download PNG"}
                </button>
                <button
                  type="button"
                  onClick={copyLink}
                  className="inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-4 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2"
                >
                  <Link2 className="size-4" />
                  Copy overlay
                </button>
              </div>
            </div>

            <div className="stage-checker flex min-h-56 items-center justify-center rounded-xl p-6 ring-1 ring-border">
              <div ref={frameRef} className={SKIN_FRAME[profile.skin]}>
                <RankWidget profile={profile} />
              </div>
            </div>

            {!profile.followElo && natural !== shown ? (
              <p className="text-sm text-muted">
                Elo {formatElo(profile.elo)} normally wears level {natural} ({bandLabel(natural)}). The badge is
                forced to level {shown}.
              </p>
            ) : (
              <p className="text-sm text-muted">
                Level {natural} is {bandLabel(natural)}.
                {shown === 10 ? " Level 10 starts at 2,001." : ""}
              </p>
            )}

            <label className="block">
              <span className="mb-1.5 block text-xs text-muted">Overlay link for OBS browser source</span>
              <input readOnly value={href} className={`${control} text-sm`} onFocus={(e) => e.currentTarget.select()} />
            </label>
            <p className="text-xs text-muted">
              Add a browser source, paste the link, set the size above, and enable a transparent background. The
              back link sits at the bottom of that page so a tight crop leaves it out.
              {notice ? <span className="ml-2 text-fg">{notice}</span> : null}
            </p>
          </section>

          <section className="order-2 flex flex-col gap-4 lg:order-1 lg:col-span-5">
            <div className="flex flex-wrap gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setProfile((prev) => keepLook(prev, preset.profile))}
                  className="h-11 rounded-lg bg-surface px-3 text-sm text-fg ring-1 ring-border transition-colors hover:bg-surface-2"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border">
              <h2 className="font-display text-sm tracking-widest text-muted">IDENTITY</h2>
              <Field label="Nickname">
                <input
                  className={control}
                  maxLength={16}
                  value={profile.nick}
                  onChange={(e) => update({ nick: e.target.value })}
                  spellCheck={false}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Region">
                  <select
                    className={control}
                    value={profile.country}
                    onChange={(e) => update({ country: e.target.value })}
                  >
                    {COUNTRIES.map((code) => (
                      <option key={code} value={code}>
                        {code}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Tag">
                  <select
                    className={control}
                    value={profile.membership}
                    onChange={(e) => update({ membership: e.target.value as Profile["membership"] })}
                  >
                    <option value="none">None</option>
                    <option value="plus">Plus</option>
                    <option value="elite">Elite</option>
                  </select>
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Toggle on={profile.verified} label="Verified" onClick={() => update({ verified: !profile.verified })} />
                <Toggle on={profile.stamp} label="FAKEIT stamp" onClick={() => update({ stamp: !profile.stamp })} />
              </div>
            </div>

            <div className="flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border">
              <h2 className="font-display text-sm tracking-widest text-muted">RANK</h2>
              <Field label="Elo" hint={formatElo(profile.elo)}>
                <input
                  type="range"
                  min={100}
                  max={5000}
                  value={Math.min(5000, profile.elo)}
                  onChange={(e) => update({ elo: Number(e.target.value) })}
                />
                <input
                  type="number"
                  min={1}
                  max={9999}
                  value={profile.elo}
                  onChange={(e) => update({ elo: Number(e.target.value) })}
                  className={`${control} mt-2 tabular-nums`}
                />
              </Field>
              <Toggle
                on={profile.followElo}
                label="Badge follows Elo"
                onClick={() => update({ followElo: !profile.followElo, level: natural })}
              />
              <div className="grid grid-cols-5 gap-2">
                {BANDS.map((band) => {
                  const active = shown === band.level;
                  return (
                    <button
                      key={band.level}
                      type="button"
                      onClick={() =>
                        update({
                          followElo: false,
                          level: band.level,
                          challenger: band.level === 10 ? profile.challenger : false,
                        })
                      }
                      className={`h-11 rounded-lg font-display text-lg text-ink transition-opacity ${LEVEL_BG[band.level]} ${
                        active ? "ring-2 ring-fg" : "opacity-70 hover:opacity-100"
                      }`}
                      aria-pressed={active}
                    >
                      {band.level}
                    </button>
                  );
                })}
              </div>
              <button
                type="button"
                onClick={() => {
                  if (profile.challenger && shown === 10) {
                    update({ challenger: false });
                    return;
                  }
                  update({
                    challenger: true,
                    level: 10,
                    followElo: natural === 10 ? profile.followElo : false,
                  });
                }}
                className={`h-11 rounded-lg font-display tracking-widest ring-1 transition-colors ${
                  profile.challenger && shown === 10
                    ? "bg-loss text-ink ring-loss"
                    : "bg-canvas text-fg ring-border hover:bg-surface-2"
                }`}
                aria-pressed={profile.challenger && shown === 10}
              >
                CHALLENGER
              </button>
              <p className="text-xs text-muted">
                Staged today: {delta > 0 ? "+" : ""}
                {delta} from {profile.wins}W {profile.losses}L. Public bands, not a live account.
              </p>
            </div>

            <div className="flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border">
              <h2 className="font-display text-sm tracking-widest text-muted">STATS</h2>
              <Field label="K/D" hint={profile.kd.toFixed(2)}>
                <input
                  type="range"
                  min={0.4}
                  max={4}
                  step={0.01}
                  value={profile.kd}
                  onChange={(e) => update({ kd: Number(e.target.value) })}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="HS %" hint={`${profile.hs}%`}>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={profile.hs}
                    onChange={(e) => update({ hs: Number(e.target.value) })}
                  />
                </Field>
                <Field label="Win rate" hint={`${profile.winRate}%`}>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={profile.winRate}
                    onChange={(e) => update({ winRate: Number(e.target.value) })}
                  />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Stepper label="Wins today" value={profile.wins} onChange={(wins) => update({ wins })} />
                <Stepper label="Losses today" value={profile.losses} onChange={(losses) => update({ losses })} />
              </div>
              <div>
                <p className="mb-1.5 text-xs text-muted">Last five</p>
                <div className="grid grid-cols-5 gap-2">
                  {profile.form.map((mark, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        const form = profile.form.slice() as Profile["form"];
                        form[i] = mark === "W" ? "L" : "W";
                        update({ form });
                      }}
                      className={`h-11 rounded-lg font-display text-lg text-ink ${mark === "W" ? "bg-win" : "bg-loss"}`}
                      aria-label={`Match ${i + 1}, ${mark === "W" ? "win" : "loss"}`}
                    >
                      {mark}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-4 rounded-xl bg-surface p-4 ring-1 ring-border">
              <h2 className="font-display text-sm tracking-widest text-muted">LOOK</h2>
              <Choice
                label="Layout"
                value={profile.skin}
                options={SKINS}
                onChange={(skin) => update({ skin })}
              />
              <Choice
                label="Plate"
                value={profile.plate}
                options={PLATES}
                onChange={(plate) => update({ plate })}
              />
              <Choice
                label="Badge"
                value={profile.badge}
                options={BADGES}
                onChange={(badge) => update({ badge })}
              />
            </div>

            <p className="text-xs text-pretty text-muted">
              Fan-made prop. Level bands match the public 1–10 Elo table. Not affiliated with FACEIT or any
              matchmaking platform. Nothing here is a real rating.
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}

function Toggle({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className="flex h-11 items-center justify-between gap-3 rounded-lg bg-canvas px-3 text-sm text-fg ring-1 ring-border"
    >
      <span>{label}</span>
      <span className={`h-5 w-9 rounded-full p-0.5 transition-colors ${on ? "bg-primary" : "bg-border"}`}>
        <span className={`block size-4 rounded-full bg-fg transition-transform ${on ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}

function Stepper({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div>
      <p className="mb-1.5 text-xs text-muted">{label}</p>
      <div className="flex h-11 overflow-hidden rounded-lg ring-1 ring-border">
        <button
          type="button"
          className="w-11 bg-canvas text-lg text-fg hover:bg-surface-2"
          onClick={() => onChange(value - 1)}
          aria-label={`Decrease ${label}`}
        >
          −
        </button>
        <span className="grid flex-1 place-items-center bg-canvas font-display text-lg tabular-nums">{value}</span>
        <button
          type="button"
          className="w-11 bg-canvas text-lg text-fg hover:bg-surface-2"
          onClick={() => onChange(value + 1)}
          aria-label={`Increase ${label}`}
        >
          +
        </button>
      </div>
    </div>
  );
}

function Choice<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { id: T; label: string }[];
  onChange: (id: T) => void;
}) {
  return (
    <div>
      <p className="mb-1.5 text-xs text-muted">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const active = option.id === value;
          return (
            <button
              key={option.id}
              type="button"
              onClick={() => onChange(option.id)}
              aria-pressed={active}
              className={`h-11 rounded-lg px-3 text-sm transition-colors ${
                active ? "bg-primary text-ink" : "bg-canvas text-fg ring-1 ring-border hover:bg-surface-2"
              }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
