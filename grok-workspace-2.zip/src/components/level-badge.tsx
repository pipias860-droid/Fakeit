import { isChallenger, LEVEL_BG, LEVEL_TEXT, type Profile, shownLevel } from "@/lib/profile";

type Props = {
  profile: Profile;
  className?: string;
};

export function LevelBadge({ profile, className = "" }: Props) {
  const level = shownLevel(profile);
  const challenger = isChallenger(profile);
  const hot = level >= 9 || challenger;
  const label = challenger ? `Challenger, level ${level}` : `Level ${level}`;

  if (profile.badge === "plate") {
    return (
      <div
        role="img"
        aria-label={label}
        className={`grid place-items-center rounded-xl font-display leading-none text-ink ${
          challenger ? "bg-loss ring-2 ring-fg" : LEVEL_BG[level]
        } ${hot ? "badge-hot" : ""} ${className}`}
      >
        {level}
      </div>
    );
  }

  const lit = challenger ? 10 : level;
  const color = challenger ? "text-loss" : LEVEL_TEXT[level];

  return (
    <svg
      viewBox="0 0 64 64"
      role="img"
      aria-label={label}
      className={`${color} ${hot ? "badge-hot" : ""} ${className}`}
    >
      <rect x="1" y="1" width="62" height="62" rx="12" fill="var(--color-surface-2)" stroke="var(--color-border)" />
      {challenger ? (
        <rect x="3.5" y="3.5" width="57" height="57" rx="10" fill="none" stroke="currentColor" strokeWidth="1.5" />
      ) : null}
      {Array.from({ length: 10 }, (_, i) => {
        const on = i >= 10 - lit;
        const fromTop = i - (10 - lit);
        const y = 7 + i * 5.15;
        return (
          <rect
            key={i}
            x="12"
            y={y}
            width="40"
            height="3.4"
            rx="1.2"
            fill={on ? "currentColor" : "var(--color-border)"}
            opacity={on ? 1 - fromTop * 0.055 : 1}
          />
        );
      })}
    </svg>
  );
}
