export const BANDS = [
  { level: 1, min: 100, max: 500 },
  { level: 2, min: 501, max: 750 },
  { level: 3, min: 751, max: 900 },
  { level: 4, min: 901, max: 1050 },
  { level: 5, min: 1051, max: 1200 },
  { level: 6, min: 1201, max: 1350 },
  { level: 7, min: 1351, max: 1530 },
  { level: 8, min: 1531, max: 1750 },
  { level: 9, min: 1751, max: 2000 },
  { level: 10, min: 2001, max: Number.POSITIVE_INFINITY },
] as const;

export const COUNTRIES = [
  "SE",
  "DK",
  "NO",
  "FI",
  "PL",
  "DE",
  "FR",
  "NL",
  "PT",
  "ES",
  "CZ",
  "UA",
  "BR",
  "US",
  "CA",
  "GB",
  "TR",
  "KZ",
  "AU",
  "JP",
] as const;

export const LEVEL_TEXT = [
  "",
  "text-lv1",
  "text-lv2",
  "text-lv3",
  "text-lv4",
  "text-lv5",
  "text-lv6",
  "text-lv7",
  "text-lv8",
  "text-lv9",
  "text-lv10",
] as const;

export const LEVEL_BG = [
  "",
  "bg-lv1",
  "bg-lv2",
  "bg-lv3",
  "bg-lv4",
  "bg-lv5",
  "bg-lv6",
  "bg-lv7",
  "bg-lv8",
  "bg-lv9",
  "bg-lv10",
] as const;

export type FormMark = "W" | "L";
export type Membership = "none" | "plus" | "elite";
export type Skin = "badge" | "signal" | "slab" | "lower" | "card";
export type Plate = "clear" | "ink" | "glass";
export type BadgeStyle = "bars" | "plate";

export type Profile = {
  nick: string;
  elo: number;
  followElo: boolean;
  level: number;
  challenger: boolean;
  kd: number;
  hs: number;
  winRate: number;
  wins: number;
  losses: number;
  form: FormMark[];
  country: string;
  membership: Membership;
  verified: boolean;
  skin: Skin;
  plate: Plate;
  badge: BadgeStyle;
  stamp: boolean;
};

export const DEFAULT_PROFILE: Profile = {
  nick: "nightshift",
  elo: 2146,
  followElo: true,
  level: 10,
  challenger: false,
  kd: 1.18,
  hs: 49,
  winRate: 54,
  wins: 3,
  losses: 1,
  form: ["W", "W", "L", "W", "W"],
  country: "SE",
  membership: "plus",
  verified: true,
  skin: "signal",
  plate: "ink",
  badge: "bars",
  stamp: true,
};

const NICKS = [
  "nightshift",
  "lowtab",
  "dust2dad",
  "mirageonly",
  "stackdiff",
  "eco_fine",
  "awp_tax",
  "banana_peel",
  "forcebuy",
  "save_round",
  "lurking",
  "headtap",
  "veto_bot",
  "ct_anchor",
  "definitely10",
];

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function levelFromElo(elo: number) {
  if (elo <= BANDS[0].max) return 1;
  for (const band of BANDS) {
    if (elo <= band.max) return band.level;
  }
  return 10;
}

export function shownLevel(profile: Profile) {
  return profile.followElo ? levelFromElo(profile.elo) : clamp(Math.round(profile.level), 1, 10);
}

export function isChallenger(profile: Profile) {
  return shownLevel(profile) === 10 && profile.challenger;
}

export type EloRead = {
  level: number;
  pct: number;
  next: number | null;
  over: number;
};

export function readElo(elo: number): EloRead {
  const level = levelFromElo(elo);
  const band = BANDS[level - 1];
  if (level === 10) {
    const over = Math.max(0, elo - 2001);
    return { level, pct: Math.min(1, over / 1000), next: null, over };
  }
  const span = band.max - band.min;
  const into = clamp(elo - band.min, 0, span);
  return {
    level,
    pct: span === 0 ? 1 : into / span,
    next: band.max + 1,
    over: 0,
  };
}

export function formatElo(n: number) {
  return Math.round(n).toLocaleString("en-US");
}

export function bandLabel(level: number) {
  const band = BANDS[clamp(level, 1, 10) - 1];
  if (band.level === 10) return "2,001+";
  return `${formatElo(band.min)}–${formatElo(band.max)}`;
}

export function todayDelta(profile: Profile) {
  return profile.wins * 25 - profile.losses * 23;
}

export function progressCopy(profile: Profile) {
  const shown = shownLevel(profile);
  const read = readElo(profile.elo);
  if (!profile.followElo) {
    if (isChallenger(profile)) return "Challenger";
    if (shown === 10) return "Level 10";
    return `Level ${shown}`;
  }
  if (read.next == null) return `${formatElo(read.over)} past 2,001`;
  const left = Math.max(0, read.next - profile.elo);
  return `${formatElo(left)} to level ${read.level + 1}`;
}

export function barState(profile: Profile) {
  const shown = shownLevel(profile);
  if (!profile.followElo) {
    return { pct: shown === 10 ? 1 : 0.72, colorLevel: shown };
  }
  const read = readElo(profile.elo);
  return { pct: read.pct, colorLevel: read.level };
}

function asForm(raw: string | undefined, fallback: FormMark[]): FormMark[] {
  if (!raw) return fallback;
  const marks = raw
    .toUpperCase()
    .split("")
    .filter((c): c is FormMark => c === "W" || c === "L");
  if (marks.length === 0) return fallback;
  while (marks.length < 5) marks.push("L");
  return marks.slice(0, 5);
}

function member(v: string | undefined): Membership {
  if (v === "plus" || v === "elite" || v === "none") return v;
  return "none";
}

export function sanitize(input: Partial<Profile>): Profile {
  const elo = clamp(Math.round(Number.isFinite(input.elo) ? (input.elo as number) : DEFAULT_PROFILE.elo), 1, 9999);
  const followElo = input.followElo !== false;
  const level = clamp(Math.round(input.level ?? levelFromElo(elo)), 1, 10);
  const form = Array.isArray(input.form) && input.form.length === 5
    ? input.form.map((m) => (m === "L" ? "L" : "W"))
    : DEFAULT_PROFILE.form;
  const skin: Skin =
    input.skin === "badge" || input.skin === "slab" || input.skin === "lower" || input.skin === "card" || input.skin === "signal"
      ? input.skin
      : "signal";
  const plate: Plate = input.plate === "clear" || input.plate === "glass" || input.plate === "ink" ? input.plate : "ink";
  const badge: BadgeStyle = input.badge === "plate" || input.badge === "bars" ? input.badge : "bars";
  const membership = member(input.membership);
  const country = COUNTRIES.includes(input.country as (typeof COUNTRIES)[number])
    ? (input.country as string)
    : DEFAULT_PROFILE.country;
  const shown = followElo ? levelFromElo(elo) : level;
  return {
    nick: (input.nick ?? DEFAULT_PROFILE.nick).slice(0, 16),
    elo,
    followElo,
    level,
    challenger: shown === 10 && Boolean(input.challenger),
    kd: Math.round(clamp(input.kd ?? DEFAULT_PROFILE.kd, 0.1, 4) * 100) / 100,
    hs: clamp(Math.round(input.hs ?? DEFAULT_PROFILE.hs), 0, 100),
    winRate: clamp(Math.round(input.winRate ?? DEFAULT_PROFILE.winRate), 0, 100),
    wins: clamp(Math.round(input.wins ?? 0), 0, 20),
    losses: clamp(Math.round(input.losses ?? 0), 0, 20),
    form,
    country,
    membership,
    verified: Boolean(input.verified),
    skin,
    plate,
    badge,
    stamp: input.stamp !== false,
  };
}

export type OverlaySearch = {
  n?: string;
  e?: number;
  cl?: number;
  ch?: number;
  k?: number;
  h?: number;
  wr?: number;
  wi?: number;
  lo?: number;
  f?: string;
  cc?: string;
  m?: string;
  v?: number;
  s?: string;
  p?: string;
  mk?: number;
  b?: string;
};

function num(v: string | number | undefined) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v))) return Number(v);
  return undefined;
}

export function profileFromSearch(search: OverlaySearch): Profile {
  const hasAny = Object.values(search).some((value) => value != null && value !== "");
  if (!hasAny) return sanitize(DEFAULT_PROFILE);

  const elo = num(search.e);
  const cl = num(search.cl);
  const custom = cl != null && cl >= 1 && cl <= 10;
  return sanitize({
    nick: search.n ?? DEFAULT_PROFILE.nick,
    elo: elo ?? DEFAULT_PROFILE.elo,
    followElo: !custom,
    level: custom ? cl : levelFromElo(elo ?? DEFAULT_PROFILE.elo),
    challenger: num(search.ch) === 1,
    kd: num(search.k),
    hs: num(search.h),
    winRate: num(search.wr),
    wins: num(search.wi),
    losses: num(search.lo),
    form: asForm(search.f, DEFAULT_PROFILE.form),
    country: search.cc,
    membership: member(search.m),
    verified: num(search.v) === 1,
    skin: search.s as Skin | undefined,
    plate: search.p as Plate | undefined,
    badge: search.b as BadgeStyle | undefined,
    stamp: num(search.mk) !== 0,
  });
}

export function toQuery(profile: Profile) {
  const q = new URLSearchParams();
  q.set("n", profile.nick);
  q.set("e", String(profile.elo));
  q.set("cl", profile.followElo ? "0" : String(shownLevel(profile)));
  q.set("ch", profile.challenger ? "1" : "0");
  q.set("k", String(profile.kd));
  q.set("h", String(profile.hs));
  q.set("wr", String(profile.winRate));
  q.set("wi", String(profile.wins));
  q.set("lo", String(profile.losses));
  q.set("f", profile.form.join(""));
  q.set("cc", profile.country);
  q.set("m", profile.membership);
  q.set("v", profile.verified ? "1" : "0");
  q.set("s", profile.skin);
  q.set("p", profile.plate);
  q.set("mk", profile.stamp ? "1" : "0");
  q.set("b", profile.badge);
  return q.toString();
}

export const PRESETS: { id: string; label: string; profile: Profile }[] = [
  {
    id: "washed",
    label: "Washed",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "dust2dad",
      elo: 612,
      followElo: true,
      challenger: false,
      kd: 0.84,
      hs: 36,
      winRate: 41,
      wins: 0,
      losses: 3,
      form: ["L", "L", "W", "L", "L"],
      country: "US",
      membership: "none",
      verified: false,
    }),
  },
  {
    id: "lobby",
    label: "Lobby",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "mirageonly",
      elo: 1124,
      followElo: true,
      kd: 1.02,
      hs: 46,
      winRate: 50,
      wins: 1,
      losses: 1,
      form: ["W", "L", "W", "L", "W"],
      country: "PL",
      membership: "none",
      verified: false,
    }),
  },
  {
    id: "grinder",
    label: "Grinder",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "stackdiff",
      elo: 1688,
      followElo: true,
      kd: 1.14,
      hs: 51,
      winRate: 55,
      wins: 2,
      losses: 1,
      form: ["W", "W", "W", "L", "W"],
      country: "DK",
      membership: "plus",
      verified: true,
    }),
  },
  {
    id: "ten",
    label: "Level 10",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "nightshift",
      elo: 2388,
      followElo: true,
      challenger: false,
      kd: 1.27,
      hs: 54,
      winRate: 58,
      wins: 4,
      losses: 1,
      form: ["W", "W", "L", "W", "W"],
      country: "SE",
      membership: "elite",
      verified: true,
    }),
  },
  {
    id: "challenger",
    label: "Challenger",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "lowtab",
      elo: 3410,
      followElo: true,
      challenger: true,
      kd: 1.42,
      hs: 58,
      winRate: 63,
      wins: 5,
      losses: 0,
      form: ["W", "W", "W", "W", "W"],
      country: "FR",
      membership: "elite",
      verified: true,
    }),
  },
  {
    id: "liar",
    label: "Obvious lie",
    profile: sanitize({
      ...DEFAULT_PROFILE,
      nick: "definitely10",
      elo: 420,
      followElo: false,
      level: 10,
      challenger: true,
      kd: 3.2,
      hs: 80,
      winRate: 92,
      wins: 9,
      losses: 0,
      form: ["W", "W", "W", "W", "W"],
      country: "BR",
      membership: "elite",
      verified: true,
      stamp: true,
    }),
  },
];

export function randomProfile(current: Profile): Profile {
  const nick = NICKS[Math.floor(Math.random() * NICKS.length)];
  const roll = Math.random();
  const elo =
    roll > 0.85 ? 2000 + Math.floor(Math.random() * 1800) : 200 + Math.floor(Math.random() * 1900);
  const form = Array.from({ length: 5 }, () => (Math.random() > 0.45 ? "W" : "L")) as FormMark[];
  const country = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
  return sanitize({
    ...current,
    nick,
    elo,
    followElo: true,
    challenger: elo > 2800 && Math.random() > 0.4,
    kd: Math.round((0.7 + Math.random() * 1.1) * 100) / 100,
    hs: 30 + Math.floor(Math.random() * 35),
    winRate: 38 + Math.floor(Math.random() * 30),
    wins: Math.floor(Math.random() * 6),
    losses: Math.floor(Math.random() * 4),
    form,
    country,
    verified: Math.random() > 0.4,
    membership: elo > 1800 ? "elite" : elo > 1100 ? "plus" : "none",
  });
}

export function keepLook(current: Profile, next: Profile): Profile {
  return sanitize({
    ...next,
    skin: current.skin,
    plate: current.plate,
    badge: current.badge,
    stamp: current.stamp,
  });
}
