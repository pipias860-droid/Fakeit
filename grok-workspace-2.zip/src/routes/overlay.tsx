import { createFileRoute, Link } from "@tanstack/react-router";
import { RankWidget } from "@/components/rank-widget";
import { profileFromSearch, type OverlaySearch } from "@/lib/profile";

function str(search: Record<string, unknown>, key: string) {
  const value = search[key];
  return typeof value === "string" ? value : undefined;
}

function num(search: Record<string, unknown>, key: string) {
  const value = search[key];
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return undefined;
}

export const Route = createFileRoute("/overlay")({
  validateSearch: (search: Record<string, unknown>): OverlaySearch => ({
    n: str(search, "n"),
    e: num(search, "e"),
    cl: num(search, "cl"),
    ch: num(search, "ch"),
    k: num(search, "k"),
    h: num(search, "h"),
    wr: num(search, "wr"),
    wi: num(search, "wi"),
    lo: num(search, "lo"),
    f: str(search, "f"),
    cc: str(search, "cc"),
    m: str(search, "m"),
    v: num(search, "v"),
    s: str(search, "s"),
    p: str(search, "p"),
    mk: num(search, "mk"),
    b: str(search, "b"),
  }),
  component: OverlayPage,
});

function OverlayPage() {
  const search = Route.useSearch();
  const profile = profileFromSearch(search);

  return (
    <div data-overlay className="min-h-screen bg-transparent">
      <div className="p-2">
        <RankWidget profile={profile} />
      </div>
      <Link
        to="/"
        className="fixed bottom-3 left-1/2 -translate-x-1/2 text-xs text-muted underline decoration-border"
      >
        Back to studio
      </Link>
    </div>
  );
}
